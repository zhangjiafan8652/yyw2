package com.yayawan.callback;

public interface YYWExitCallback {

    public abstract void onExit();
}
