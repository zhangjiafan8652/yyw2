package com.yayawan.utils;

/**
 * 游戏自检测试工具类
 * @author zhangjiafan
 *
 */
public class GameTestUtils {

	public  static void setData(){
		
		  
	}
	
}
