package com.yayawan.utils;


public class UrlConstants {

	public static String baseurl=ViewConstants.baseurl;

	
	public static String active=baseurl+"data/active_handler/";//激活回调
	
	
}
