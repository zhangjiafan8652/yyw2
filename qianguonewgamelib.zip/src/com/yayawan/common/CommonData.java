package com.yayawan.common;

public class CommonData {


//	5.9 微调了界面，改变了支付获取方式
//	5.8 增加测试流程
//	5.7 丫丫玩盒子公告延迟3分钟显示
//	5.6 统一了千果千其代码
//	5.5 修改了调试模式  增加了两个适配接口
//	5.0 加入空白sdk  在配置文件sdktype中配置
//	4.9 修复老微信支付
//	4.8 增加代金券支付
//	4.7 删除多余小助手代码
	
	public static final String SDKVERSION = "5.92";
	
	
 public static	String sdkid="qianguo_app_id";

 public static String Dbpath="QianGuoUserData";

 public static String BaseUrl="https://api.kingoo.com.cn/";
 

 public static String exiturl="exiturl";
 public static  String YONGHUXIEYIURL="https://api.kingoo.com.cn/web/s/3104502393?nohead=1";

 public static  int BLUEP=37;
// public static  int BLUEP=51;
 public static String bluepmd5string="c7a9d9e6a2b58de3f16848c599774a08";
 
 public static  int GREENP=36;
// public static  int GREENP=51;
 public static String greenpmd5string="0e96242145da349f1463a8ae270cb79c";
 public static  int DAIJINJUANPAY=40;
 public static String daijinjuanpaymd5string="00f1dfe8e0fa6f75e4dee0c28bde4d74";

 public static  int YAYABIPAY=38;
 public static String yayabipaymd5string="fd7df8195842f26d0ee7d6a9a76708de";
 //https://api.kingoo.com.cn/web/s/3104502393?nohead=1
	 
}
