package com.yayawan.proxy;

public class YYcontants {

	
	public static boolean ISDEBUG=false;
}
