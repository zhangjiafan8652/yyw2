package com.yayawan.sdk.parser;

import org.json.JSONException;
import org.json.JSONObject;

import android.widget.Toast;

import com.yayawan.sdk.bean.User;

public class UserParser {

	

}
