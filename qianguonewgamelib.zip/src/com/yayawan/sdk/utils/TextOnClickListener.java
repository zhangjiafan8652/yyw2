package com.yayawan.sdk.utils;

public abstract class TextOnClickListener {

	
		public  abstract void onclick();
	
}
