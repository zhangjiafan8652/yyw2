package com.yayawan.sdk.utils;

public class CardInfo {

    public static final String YIDONGCARDNUM = "yidongcardnum";

    public static final String YIDONGCARDPASS = "yidongcardpass";

    public static final String LIANTONGCARDNUM = "liantongcardnum";

    public static final String LIANTONGCARDPASS = "liantongcardpass";

    public static final String DIANXINCARDNUM = "dianxincardnum";

    public static final String DIANXINCARDPASS = "dianxincardpass";

    public static final String SHENGDACARDNUM = "shengdacardnum";

    public static final String SHENGDACARDPASS = "shengdacardpass";

    public static final String JUNWANGCARDNUM = "junwangcardnum";

    public static final String JUNWANGCARDPASS = "junwangcardpass";

    public static final String QQCARDNUM = "qqcardnum";

    public static final String QQCARDPASS = "qqcardpass";

    public static final String CREDITCARDNUM = "creditcardnum";

    public static final String CREDITCARDPHONE = "creditcardphone";

    public static final String CREDITCARDPVALPERIOD = "creditcardpvalperiod";

    public static final String CREDITCARIDENNUM = "creditcaridennum";

    public static final String CASHCARDNUM = "cashcardnum";

    public static final String CASHCARDPHONE = "cashcardphone";

    public static final String CASHCARDNAME = "cashcardname";

    public static final String CASHCARDID = "cashcardid";

}
