package com.yayawan.sdk.utils;

public class AppUtils {

	
	
	
}
