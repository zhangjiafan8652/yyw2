package com.yayawan.sdk.utils;


import com.yayawan.utils.DeviceUtil;

public class RequestParams {

	public RequestParams(){
		
	}
	
	public void addBodyParameter(){
		//RequestParams rps = new RequestParams();
		
	}
}
