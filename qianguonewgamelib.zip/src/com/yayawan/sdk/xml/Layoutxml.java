package com.yayawan.sdk.xml;

import android.view.View;

public interface Layoutxml {

	public View initViewxml();
}
