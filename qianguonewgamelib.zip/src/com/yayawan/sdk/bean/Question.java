package com.yayawan.sdk.bean;

/**
 * 帮助中心
 * 
 * @author wjy
 * 
 */
public class Question {

    public String id; // 问题id

    public String name; // 问题标题

    public String content; // 问题内容

}
