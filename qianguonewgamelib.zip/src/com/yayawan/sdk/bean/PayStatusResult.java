package com.yayawan.sdk.bean;

import java.util.ArrayList;

/**
 * 消费记录
 * @author wjy
 *
 */
public class PayStatusResult {

    public int success;
    
    public int total;
    public ArrayList<PayLog> payLogs;
    
}
