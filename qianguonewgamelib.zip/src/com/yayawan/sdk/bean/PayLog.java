package com.yayawan.sdk.bean;
/**
 * 消费记录明细
 * @author wjy
 *
 */
public class PayLog {

    public String id;
    public String bank_id;
    public String bank_name;
    public String amount;
    public String goods;
    public String date_time;
    public int status;
    public String status_msg;
    
}
