package com.yayawan.sdk.bean;

public class BillResult {
    
    public int success;
    public int good;
    public String body;
    public int error_code;
    public String error_msg;
}
