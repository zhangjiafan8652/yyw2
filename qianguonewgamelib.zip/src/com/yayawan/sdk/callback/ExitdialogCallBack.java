package com.yayawan.sdk.callback;

public interface ExitdialogCallBack {
	public abstract  void goExit();
}
